import * as React from 'react';
import { View, Text, Button } from 'react-native';
import { NavigationContainer, Navigation} from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import {useNavigation} from '@react-navigation/native';

export default function AdminScreen() {

  const navigation = useNavigation();

  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>
        Admin Screen
      </Text>
    </View>
  );
}