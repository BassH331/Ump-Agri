import React, { useState } from 'react';
import { View, Text, Button, ScrollView, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { NavigationContainer, Navigation} from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Ionicons, FontAwesome5 } from '@expo/vector-icons';
import {useNavigation} from '@react-navigation/native';
import diningHall_B13 from '../../Campus_img/Lecture_halls_B5.jpg';
import labs from '../../Campus_img/ICT_labs.jpg';

const buildings = [
  {
    id: '1',
    name: 'ICT Building 5 - ICT labs',
    image: labs,  
  },
  {
    id: '2',
    name: 'Lecture Halls - Building 5',
    image: diningHall_B13, 
  },
];

export default function EducationScreen() {

  const [favorites, setFavorites] = useState([]);

  const toggleFavorite = (id) => {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((fav) => fav !== id) : [...prev, id]
    );
  };


  const navigation = useNavigation();

  return (
    <ScrollView contentContainerStyle={styles.scroll}>
        {buildings.map((item) => (
          <View key={item.id} style={styles.card}>
            <Image source={item.image} style={styles.image} />
            <View style={styles.textRow}>
              <Text style={styles.buildingName}>{item.name}</Text>
              <TouchableOpacity onPress={() => toggleFavorite(item.id)}>
                <Ionicons
                  name={favorites.includes(item.id) ? 'star' : 'star-outline'}
                  size={24}
                  color="orange"
                />
              </TouchableOpacity>
            </View>
            <View style={styles.actions}>
              <TouchableOpacity
                style={styles.button}
                onPress={() => handlePress('Directions', item.name)}
              >
                <FontAwesome5 name="route" size={16} color="orange" />
                <Text style={styles.buttonText}>DIRECTIONS</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.button}
                onPress={() => handlePress('Walking', item.name)}
              >
                <FontAwesome5 name="walking" size={16} color="orange" />
                <Text style={styles.buttonText}>WALKING</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.button}
                onPress={() => handlePress('Voice', item.name)}
              >
                <FontAwesome5 name="volume-up" size={16} color="orange" />
                <Text style={styles.buttonText}>VOICE</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </ScrollView>
  );
}

const styles = StyleSheet.create({

  scroll: {
    paddingHorizontal: 16,
    paddingBottom: 20,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 12,
    marginVertical: 12,
    padding: 12,
    elevation: 3,
    shadowColor: 'orange',
    shadowOpacity: 0.2,
    shadowOffset: { width: 1, height: 2 },
    shadowRadius: 5,
  },
  image: {
    width: '100%',
    height: 160,
    borderRadius: 10,
  },
  textRow: {
    marginTop: 10,
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  buildingName: {
    fontSize: 16,
    flex: 1,
    fontWeight: '500',
    color: '#d35400',
    marginRight: 8,
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    borderColor: 'orange',
    borderWidth: 1,
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 8,
  },
  buttonText: {
    color: 'orange',
    marginLeft: 6,
    fontWeight: '500',
  },
});