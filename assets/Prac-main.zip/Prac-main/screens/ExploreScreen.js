import * as React from 'react';
import { View, Text, Button } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import {useNavigation} from '@react-navigation/native';


export default function HomeScreen() {

  const navigation = useNavigation();

  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Explore Screen</Text>
      <Button
        onPress={() => navigation.navigate('Admin')}
        title = {"Admin"}>
      </Button>
      <Button
        onPress={() => navigation.navigate('Food')}
        title = {"Food"}>
      </Button>
      <Button
        onPress={() => navigation.navigate('Education')}
        title = {"Education"}>
      </Button>
      <Button
        onPress={() => navigation.goBack()}
        title = {"Return to Home Page"}>
      </Button>
    </View>
  );
}