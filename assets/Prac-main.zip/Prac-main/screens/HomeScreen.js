import * as React from 'react';
import {
  View,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Animated,
  Platform,
  useWindowDimensions,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import WebView from 'react-native-webview';
import { Button } from '@rneui/base';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

export default function HomeScreen() {

  const { width: screenWidth } = useWindowDimensions(); // Get the current screen width

  //Define how the suggestion box should change accroding to the size of the screen
  if (screenWidth < 400) {
    // Small screens (e.g., iPhone SE, older Android phones)
    boxWidth = '95%'; // Take up 95% of the screen width
  } else if (screenWidth >= 400 && screenWidth < 768) {
    // Normal/medium screens (e.g., most iPhones, standard Android phones)
    boxWidth = '90%'; // Take up 90% of the screen width
  } else if (screenWidth >= 768 && screenWidth < 1024) {
    // Tablet-like screens (e.g., smaller iPads, larger Android tablets)
    boxWidth = '70%'; // Take up 70%
  } else {
    // Large screens (e.g., larger iPads, foldable devices unfolded, web view on desktop)
    boxWidth = 600; // You can also set a fixed maximum width for very large screens
                     // Or '50%' if you want it to scale more
  }

  const textColor = Platform.OS === 'ios' ? 'white' : '#f3682b';
  const shakeAnim = React.useRef(new Animated.Value(0)).current;

  React.useEffect(() => {
    const shake = () => {
      Animated.sequence([
        Animated.timing(shakeAnim, {
          toValue: 5,
          duration: 50,
          useNativeDriver: true,
        }),
        Animated.timing(shakeAnim, {
          toValue: -5,
          duration: 50,
          useNativeDriver: true,
        }),
        Animated.timing(shakeAnim, {
          toValue: 0,
          duration: 50,
          useNativeDriver: true,
        }),
      ]).start();
    };

    // Call `shake()` every 3 seconds
    const interval = setInterval(shake, 3000); // ⬅️ Change this for different intervals

    return () => clearInterval(interval); // Clean up on unmount
  }, []);

  const navigation = useNavigation();

  // HTML for Leaflet map
  const mapHtml = `
    <!DOCTYPE html>
    <html>
      <head>
        <title>Map</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
        <style>
          #map { height: 100%; width: 100%; }
          html, body { margin: 0; padding: 0; height: 100%; }
        </style>
      </head>
      <body>
        <div id="map"></div>
        <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
        <script>
          var map = L.map('map').setView([-26.2041, 28.0473], 13); // Johannesburg
          L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          }).addTo(map);
        </script>
      </body>
    </html>
  `;

  return (
    <View style={styles.container}>
    
      <ScrollView
        horizontal={true}
        showsHorizontalScrollIndicator={false}
        style={styles.scrollView}>
        <View style={[styles.suggestionBox, { minWidth: screenWidth }]}>
          <View style={[styles.buttonContainer, { marginHorizontal: 15}]}>
            <Button
              onPress={() => navigation.navigate('Food')}
              title="Food"
              color={textColor}
              ViewComponent={LinearGradient} // Don't forget this!
              linearGradientProps={{
                colors: ["darkblue", "turquoise"],
                start: { x: 0.5, y: 0.5 },
                end: { x: 1, y: 0.5 },
              }}
              Linear Gradient
            >
              <Ionicons name="fast-food-outline" size={24} color="white" paddingHorizontal={5}/>Food
            </Button>
          </View>
          <View style={[styles.buttonContainer, { marginHorizontal: 15}]}>
            <Button
              onPress={() => navigation.navigate('Admin')}
              title="Admin"
              color={textColor}
              ViewComponent={LinearGradient} // Don't forget this!
              linearGradientProps={{
                colors: ["darkblue", "turquoise"],
                start: { x: 0.5, y: 0.5 },
                end: { x: 1, y: 0.5 },
              }}
              Linear Gradient
            >
              <Ionicons name="business-outline" size={24} color="white" paddingHorizontal={5}/>Admin
            </Button>
          </View>
          <View style={[styles.buttonContainer, { marginHorizontal: 15 }]}>
            <Button
              onPress={() => navigation.navigate('Education')}
              title="Lecture Halls"
              color={textColor}
              ViewComponent={LinearGradient} // Don't forget this!
              linearGradientProps={{
                colors: ["darkblue", "turquoise"],
                start: { x: 0.5, y: 0.5 },
                end: { x: 1, y: 0.5 },
              }}
              Linear Gradient
            >
              <Ionicons name="book-outline" size={24} color="white" paddingHorizontal={5}/>Lecture Venues
            </Button>
          </View>
          <View style={[styles.buttonContainer, { marginHorizontal: 15 }]}>
            <Button
              onPress={() => navigation.navigate('Education')}
              title="Libraries"
              color={textColor}
              ViewComponent={LinearGradient} // Don't forget this!
              linearGradientProps={{
                colors: ["darkblue", "turquoise"],
                start: { x: 0.5, y: 0.5 },
                end: { x: 1, y: 0.5 },
              }}
              Linear Gradient
            >
              <Ionicons name="library-outline" size={24} color="white" paddingHorizontal={5}/>Libraries
            </Button>
          </View>
          <View style={[styles.buttonContainer, { marginHorizontal: 15 }]}>
            <Button
              onPress={() => navigation.navigate('Education')}
              title="Computer Labs"
              color={textColor}
              ViewComponent={LinearGradient} // Don't forget this!
              linearGradientProps={{
                colors: ["darkblue", "turquoise"],
                start: { x: 0.5, y: 0.5 },
                end: { x: 1, y: 0.5 },
              }}
              Linear Gradient
            >
              <Ionicons name="desktop-outline" size={24} color="white" paddingHorizontal={5}/       >Computer Labs
            </Button>
          </View>
          <View style={[styles.buttonContainer, { marginHorizontal: 15 }]}>
            <Button
              onPress={() => navigation.navigate('Education')}
              title="Parking"
              color={textColor}
              ViewComponent={LinearGradient} // Don't forget this!
              linearGradientProps={{
                colors: ["darkblue", "turquoise"],
                start: { x: 0.5, y: 0.5 },
                end: { x: 1, y: 0.5 },
              }}
              Linear Gradient
            >
              <Ionicons name="car-sport-outline" size={24} color="white" paddingHorizontal={5}/>Parking
            </Button>
          </View>
          <View style={[styles.buttonContainer, { marginHorizontal: 15 }]}>
            <Button
              onPress={() => navigation.navigate('Education')}
              title="Residencies"
              color={textColor}
              ViewComponent={LinearGradient} // Don't forget this!
              linearGradientProps={{
                colors: ["darkblue", "turquoise"],
                start: { x: 0.5, y: 0.5 },
                end: { x: 1, y: 0.5 },
              }}
              Linear Gradient
            >
              <Ionicons name="home-outline" size={24} color="white" paddingHorizontal={5}/>Residencies
            </Button>
          </View>
          <View style={[styles.buttonContainer, { marginHorizontal: 15 }]}>
            <Button
              onPress={() => navigation.navigate('Education')}
              title="Residencies"
              color={textColor}
              ViewComponent={LinearGradient} // Don't forget this!
              linearGradientProps={{
                colors: ["darkblue", "turquoise"],
                start: { x: 0.5, y: 0.5 },
                end: { x: 1, y: 0.5 },
              }}
              Linear Gradient
            >
              <Ionicons name="walk-outline" size={24} color="white" paddingHorizontal={5}/>Toilets
            </Button>
          </View>
          <View style={[styles.buttonContainer, { marginHorizontal: 15 }]}>
          </View>
        </View>
      </ScrollView>
      <View style={styles.mapContainer}>
        <WebView
          originWhitelist={['*']}
          source={{ html: mapHtml }}
          style={styles.webView}
        />
        <Animated.View
          style={[
            styles.locationImageContainer,
            {
              transform: [
                { translateX: -15 },
                { translateY: -15 },
                { translateX: shakeAnim },
              ],
            },
          ]}>
          <TouchableOpacity>
            <Image
              source={require('../assets/location.png')}
              style={styles.locationImage}
              resizeMode="contain"
            />
          </TouchableOpacity>
        </Animated.View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  suggestionBox: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: 'transparent',
    paddingVertical: 10,
    padding: 10,
    maxWidth: 1900
  },
  buttonContainer: {
    flexDirection: 'row',
    elevation: 10
  },
  scrollView: {
    flexGrow: 0,
  },
  mapContainer: {
    flex: 1,
    position: 'relative',
  },
  webView: {
    flex: 1,
    height: 300, // Adjust height as needed
  },
  locationImageContainer: {
    position: 'absolute',
    top: '80%',
    left: '80%',
    transform: [{ translateX: -15 }, { translateY: -15 }], // Center the image
  },
  locationImage: {
    width: 60,
    height: 60,
    elevation: 10,
  },
});
