import { View, StyleSheet, Text, Platform, TextInput } from 'react-native';
import React from 'react';

export default function CustomExploreHeader() {
  const [searchText, setSearchText] = React.useState('');
  return (
    <View style={styles.headerContainer}>
      <View style={styles.searchContainer}>
        <Text style={styles.searchIcon}>🔍</Text>
        <TextInput
          style={styles.searchInput}
          placeholder="Search locations..."
          placeholderTextColor="#B0B0B0"
          value={searchText}
          onChangeText={setSearchText}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  headerContainer: {
    marginLeft: 100,
    backgroundColor: '#FECA97',
    paddingVertical: 8,
    paddingHorizontal: 10,
    alignItems: 'center', // Center the search bar horizontally
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '80%', // Occupy 80% of header width
    backgroundColor: '#B0B0B0',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  searchIcon: {
    fontSize: 18,
    color: '#E0E0E0',
    marginRight: 6,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    color: '#E0E0E0',
    height: 28,
  },
});